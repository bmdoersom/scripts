// Script for Search Bar
// Developed in-house for our search modal
(function ($) {
    'use strict';
    $.fn.searchbar = function (userOptions) {
        var searchBar = this,
            lastContent,
            options,
            bindButton = function (button, options) {
                // When the button is clicked, search
                button.click(function () {
                    executeSearch(getContents(), options);
                });
                // When the enter key is pressed in the search bar, search
                searchBar.keypress(function (e) {
                    var keycode = (e.keycode ? e.keycode : e.which);
                    if (keycode == '13') {
                        executeSearch(getContents(), options);
                    }
                });
            },
            bindInitialContent = function (content) {
                // When the user edits the text in the original search bar, copy that text
                content.on('keyup mouseup', function () {
                    setContents(content.val());
                    lastContent = ''; // Always perform a new search from the original search bar
                });
                // When the enter key is pressed in the search bar, trigger a click of the search button
                content.keypress(function (e) {
                    var keycode = (e.keycode ? e.keycode : e.which);
                    if (keycode == '13') {
                        $(options.buttonSelector).trigger('click');
                    }
                });
            },
            getContents = function () {
                return searchBar.val();
            },
            setContents = function (contents) {
                searchBar.val(contents);
                lastContent = contents;
            },
            executeSearch = function (searchText, options) {
                // If the content has changed (or user has clicked the initial content), search. Otherwise, do nothing.
                if (searchText != lastContent) {
                    lastContent = searchText;
                    console.log(searchText);
                    // Search for relevant pages based on text
                    var results = findResults(searchText);
                    // Update the results from the search
                    updateResults(results, options); 
                }
            },
            findResults = function (searchText) {
                // Currently a dummy function
                // Do stuff to get an array of result objects (each result should have text and a link)
                return [ {text: searchText, link: '#'}, {text: searchText + ', but different', link: '#'} ];
            },
            updateResults = function (results, options) {
                var resultsFrame = $(options.resultsSelector);
                // Remove the old results
                resultsFrame.empty();
                // Display the new results
                resultsFrame.prepend('<h6 class="card-subtitle">Search results for "' + getContents() + '":</h6>');
                for (var i in results) {
                    // Display the results nicely
                    resultsFrame.append('<li class="list-group item py-2"><a class="nav-link" href="' +
                        results[i].link + '">' + results[i].text + '</a></li>');
                }
            };
        
        // Set up the search bar and results
        options = $.extend({}, $.fn.searchbar.defaults, userOptions);
        // Set the contents of the search bar to the initial value
        bindInitialContent($(options.initialContentSelector));
        // Bind the search button(s)
        bindButton($(options.buttonSelector), options);
    };

    // Default options
    $.fn.searchbar.defaults = {
        initialContentSelector: '[data-role=searchInitialContent]',
        buttonSelector: '[data-role=searchButton]',
        resultsSelector: '[data-role=searchResults]'
    };

}(window.jQuery));

// Show an element on call
function showElement(id) {
    document.getElementById(id).style.display = "inline";
}

function hideElement(id) {
    document.getElementById(id).style.display = "block";
}

// Script for jQuery Hotkeys
// Modified from: https://github.com/jeresig/jquery.hotkeys
// Included for WYSIWYG Editor
(function(jQuery){
	
	jQuery.hotkeys = {
		version: "0.8",

		specialKeys: {
			8: "backspace", 9: "tab", 13: "return", 16: "shift", 17: "ctrl", 18: "alt", 19: "pause",
			20: "capslock", 27: "esc", 32: "space", 33: "pageup", 34: "pagedown", 35: "end", 36: "home",
			37: "left", 38: "up", 39: "right", 40: "down", 45: "insert", 46: "del", 
			96: "0", 97: "1", 98: "2", 99: "3", 100: "4", 101: "5", 102: "6", 103: "7",
			104: "8", 105: "9", 106: "*", 107: "+", 109: "-", 110: ".", 111 : "/", 
			112: "f1", 113: "f2", 114: "f3", 115: "f4", 116: "f5", 117: "f6", 118: "f7", 119: "f8", 
			120: "f9", 121: "f10", 122: "f11", 123: "f12", 144: "numlock", 145: "scroll", 191: "/", 224: "meta"
		},
	
		shiftNums: {
			"`": "~", "1": "!", "2": "@", "3": "#", "4": "$", "5": "%", "6": "^", "7": "&", 
			"8": "*", "9": "(", "0": ")", "-": "_", "=": "+", ";": ": ", "'": "\"", ",": "<", 
			".": ">",  "/": "?",  "\\": "|"
		}
	};

	function keyHandler( handleObj ) {
		// Only care when a possible input has been specified
		if ( typeof handleObj.data !== "string" ) {
			return;
		}
		
		var origHandler = handleObj.handler,
			keys = handleObj.data.toLowerCase().split(" "),
			textAcceptingInputTypes = ["text", "password", "number", "email", "url", "range", "date", "month", "week", "time", "datetime", "datetime-local", "search", "color"];
	
		handleObj.handler = function( event ) {
			// Don't fire in text-accepting inputs that we didn't directly bind to
			if ( this !== event.target && (/textarea|select/i.test( event.target.nodeName ) ||
				jQuery.inArray(event.target.type, textAcceptingInputTypes) > -1 ) ) {
				return;
			}
			
			// Keypress represents characters, not special keys
			var special = event.type !== "keypress" && jQuery.hotkeys.specialKeys[ event.which ],
				character = String.fromCharCode( event.which ).toLowerCase(),
				key, modif = "", possible = {};

			// check combinations (alt|ctrl|shift+anything)
			if ( event.altKey && special !== "alt" ) {
				modif += "alt+";
			}

			if ( event.ctrlKey && special !== "ctrl" ) {
				modif += "ctrl+";
			}
			
			// TODO: Need to make sure this works consistently across platforms
			if ( event.metaKey && !event.ctrlKey && special !== "meta" ) {
				modif += "meta+";
			}

			if ( event.shiftKey && special !== "shift" ) {
				modif += "shift+";
			}

			if ( special ) {
				possible[ modif + special ] = true;

			} else {
				possible[ modif + character ] = true;
				possible[ modif + jQuery.hotkeys.shiftNums[ character ] ] = true;

				// "$" can be triggered as "Shift+4" or "Shift+$" or just "$"
				if ( modif === "shift+" ) {
					possible[ jQuery.hotkeys.shiftNums[ character ] ] = true;
				}
			}

			for ( var i = 0, l = keys.length; i < l; i++ ) {
				if ( possible[ keys[i] ] ) {
					return origHandler.apply( this, arguments );
				}
			}
		};
	}

	jQuery.each([ "keydown", "keyup", "keypress" ], function() {
		jQuery.event.special[ this ] = { add: keyHandler };
	});

})( jQuery );

// Script for WYSIWYG Editor
// Modified from: http://github.com/mindmup/bootstrap-wysiwyg 
// (copied from bootstrap-wysiwyg.js, depends only on jQuery Hotkeys above)
// Licensed under the MIT License (included in static/licenses/bootstrap-wysiwyg)
(function ($) {
	'use strict';
	var readFileIntoDataUrl = function (fileInfo) {
		var loader = $.Deferred(),
			fReader = new FileReader();
		fReader.onload = function (e) {
			loader.resolve(e.target.result);
		};
		fReader.onerror = loader.reject;
		fReader.onprogress = loader.notify;
		fReader.readAsDataURL(fileInfo);
		return loader.promise();
	};
	/*$.fn.cleanHtml = function () {
		var html = $(this).html();
		return html && html.replace(/(<br>|\s|<div><br><\/div>|&nbsp;)*$/, '');
	};*/
	$.fn.wysiwyg = function (userOptions) {
		var editor = this,
			selectedRange,
			options,
			toolbarBtnSelector,
			updateToolbar = function () {
				if (options.activeToolbarClass) {
					// Find all the buttons in the toolbar labeled with the toolbarBtnSelector
					$(options.toolbarSelector).find(toolbarBtnSelector).each(function () {
						// Get the command a button sends
						var command = $(this).data(options.commandRole);
						// Check the state of the command and set the button's appearance accordingly
						if (document.queryCommandState(command)) {
							$(this).removeClass(options.inactiveToolbarClass);
							$(this).addClass(options.activeToolbarClass);
						} else {
							$(this).removeClass(options.activeToolbarClass);
							$(this).addClass(options.inactiveToolbarClass);
						}
                    });
                }
                if (options.fontColorSelector && options.fontFaceSelector) {
                    // Update the font buttons to show the current font properties
                    var selectedElement = getCurrentRange().startContainer.parentElement;
                    if (selectedElement.firstElementChild && selectedElement.firstElementChild.className == 'editor'){
                        while (selectedElement.firstElementChild) {
                            selectedElement = selectedElement.firstElementChild;
                        }
                    }
                    // Find the element with the font face
                    var fontElement = selectedElement, colorElement = selectedElement;
                    while (!fontElement.hasAttribute('face')) {
                        fontElement = fontElement.parentElement;
                    }
                    var font = fontElement.attributes.face.nodeValue;
                    // Find the element with the font color
                    while (!$(colorElement).css('color')) {
                        colorElement = colorElement.parentElement;
                    }
                    var color = $(colorElement).css('color');

                    // Update the font face selector
                    $(options.fontFaceSelector).html('<font face="' + font + '">' + font + '</font>');
                    // Update the font color selector
                    $(options.fontColorSelector).css('color', color);
                }
			},
			execCommand = function (commandWithArgs, valueArg) {
				// Get the command out of the string and pass the rest as parameters
				var commandArr = commandWithArgs.split(' '),
					command = commandArr.shift(),
					args = commandArr.join(' ') + (valueArg || '');
				document.execCommand(command, 0, args);
				// Update the toolbar based on command changes
				updateToolbar();
			},
			bindHotkeys = function (hotKeys) {
				// For each hotkey, bind the command to the keypress
				$.each(hotKeys, function (hotkey, command) {
					// On key press
					editor.keydown(hotkey, function (e) {
						if (editor.attr('contenteditable') && editor.is(':visible')) {
							e.preventDefault();		// Override the browser defaults
							e.stopPropagation();
							execCommand(command);	// Execute the associated command
						}
					// On key release
					}).keyup(hotkey, function (e) {
						if (editor.attr('contenteditable') && editor.is(':visible')) {
							e.preventDefault();		// Override the browser defaults
							e.stopPropagation();
						}
					});
				});
			},
			getCurrentRange = function () {
				// Get the currently selected text from the window
				var selection = window.getSelection();
				if (selection.getRangeAt && selection.rangeCount) {
					return selection.getRangeAt(0);
				}
			},
			saveSelection = function () {
				// Save the selected text so we can restore it later
				selectedRange = getCurrentRange();
			},
			restoreSelection = function () {
				// Get the currently selected text from the window
				var selection = window.getSelection();
				// If there is a saved selection, replace the selection with the saved range
				if (selectedRange && (selectedRange in editor)) {
					// Remove the selection
					try {
						selection.removeAllRanges();
					} catch (ex) {
						document.body.createTextRange().select();
						document.selection.empty();
					}
					// Add the previous selection
					selection.addRange(selectedRange);
				}
			},
			insertFiles = function (files) {
				editor.focus();		// Focus to the editor
				// Read in each file or display an error
				$.each(files, function (idx, fileInfo) {
					// If the file is valid, display it
					if (/^image\//.test(fileInfo.type)) {
						$.when(readFileIntoDataUrl(fileInfo)).done(function (dataUrl) {
							execCommand('insertimage', dataUrl);
						}).fail(function (e) {
							options.fileUploadError("file-reader", e);
						});
					} 
					// Otherwise, display an error
					else {
						options.fileUploadError("unsupported-file-type", fileInfo.type);
					}
				});
			},
			markSelection = function (input, color) {
				restoreSelection();
				if (document.queryCommandSupported('hiliteColor')) {
					document.execCommand('hiliteColor', 0, color || 'transparent');
				}
				saveSelection();
				input.data(options.selectionMarker, color);
			},
			bindToolbar = function (toolbar, options) {
				// Whenever a toolbar button is clicked...
				toolbar.find(toolbarBtnSelector).click(function () {
					// Restore the previous text selection
					restoreSelection();
					// Focus to the editor to assign the correct target to the toolbar
					$($(toolbar).attr('data-target')).focus();
					// Execute the command(s) associated with the button
					execCommand($(this).data(options.commandRole));
					// Save the selection as the currently selected text
					saveSelection();
					// Focus to the editor again to trigger a new toolbar update
					$($(toolbar).attr('data-target')).focus();
				});
				// Keep the selection when a toolbar dropdown is clicked
				toolbar.find('[data-toggle=dropdown]').click(restoreSelection());

				toolbar.find('input[type=text][data-' + options.commandRole + ']').on('webkitspeechchange change', function () {
					var newValue = this.value; /* ugly but prevents fake double-calls due to selection restoration */
					this.value = '';
					restoreSelection();
					if (newValue) {
						editor.focus();
						execCommand($(this).data(options.commandRole), newValue);
					}
					saveSelection();
				}).on('focus', function () {
					var input = $(this);
					if (!input.data(options.selectionMarker)) {
						markSelection(input, options.selectionColor);
						input.focus();
					}
				}).on('blur', function () {
					var input = $(this);
					if (input.data(options.selectionMarker)) {
						markSelection(input, false);
					}
				});
				toolbar.find('input[type=file][data-' + options.commandRole + ']').change(function () {
					restoreSelection();
					if (this.type === 'file' && this.files && this.files.length > 0) {
						insertFiles(this.files);
					}
					saveSelection();
					this.value = '';
				});
			},
			initFileDrops = function () {
				editor.on('dragenter dragover', false)
					.on('drop', function (e) {
						var dataTransfer = e.originalEvent.dataTransfer;
						e.stopPropagation();
						e.preventDefault();
						if (dataTransfer && dataTransfer.files && dataTransfer.files.length > 0) {
							insertFiles(dataTransfer.files);
						}
					});
			};

		// Set up the wysiwyg editor
		options = $.extend({}, $.fn.wysiwyg.defaults, userOptions);
		toolbarBtnSelector = 'a[data-' + options.commandRole + '],button[data-' + options.commandRole + '],input[type=button][data-' + options.commandRole + ']';
		// Bind hotkeys (uses jQuery Hotkeys)
		bindHotkeys(options.hotKeys);
		// Prepare for drag and drop file input
		if (options.dragAndDropImages) {
			initFileDrops();
		}
		// Bind the toolbar
		bindToolbar($(options.toolbarSelector), options);
		// On these events...
		editor.attr('contenteditable', true).on('mouseup keyup focus', function () {
				saveSelection();	// Save the current selection
				var id = document.activeElement.id;
				editor = $('#' + id);
                $('#editorToolbar').attr('data-target', '#' + id);	// Set the toolbar to target the correct editor
                updateToolbar();	// update the toolbar with the current commands
			});
		// Bind for touch input
		$(window).bind('touchend', function (e) {
			var isInside = (editor.is(e.target) || editor.has(e.target).length > 0),
				currentRange = getCurrentRange(),
				clear = currentRange && (currentRange.startContainer === currentRange.endContainer && currentRange.startOffset === currentRange.endOffset);
			if (!clear || isInside) {
				saveSelection();
				updateToolbar();
			}
		});
		return this;
	};
	
	// Default options
	$.fn.wysiwyg.defaults = {
		hotKeys: {
			'ctrl+b meta+b': 'bold',
			'ctrl+i meta+i': 'italic',
			'ctrl+u meta+u': 'underline',
			'ctrl+z meta+z': 'undo',
			'ctrl+y meta+y meta+shift+z': 'redo',
			'ctrl+l meta+l': 'justifyleft',
			'ctrl+r meta+r': 'justifyright',
			'ctrl+e meta+e': 'justifycenter',
			'ctrl+j meta+j': 'justifyfull',
			'ctrl+left': 'outdent',
			'ctrl+right': 'indent',
		},
		toolbarSelector: '[data-role=editor-toolbar]',
		commandRole: 'edit',
		activeToolbarClass: 'btn-primary',
        inactiveToolbarClass: 'btn-tool',
        fontFaceSelector: '[data-role=font-face-selector]',
        fontColorSelector: '[data-role=font-color-selector]',
		selectionMarker: 'edit-focus-marker',
		selectionColor: 'darkgrey',
		dragAndDropImages: true,
		fileUploadError: function (reason, detail) { console.log("File upload error", reason, detail); }
	};
}(window.jQuery));

// Displays the current date
function date() {
    var d = new Date();
    $("#date").append(d);
}
// Makes the progress bar dynamic
(function ($) {
    $.fn.progress=function () {
        var i = 0;
        var element=document.getElementById("progressBar");
        makeProgress=function(){
            if(i < 100){
                i = i + 1;
                $(".progress-bar").css("width", i + "%").text(i + " %");
            }
            setTimeout("makeProgress()", 1000);
        }
        makeProgress();
    }
}(window.jQuery));    

// JS for tooltip styling
$(function() {
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle-second="tooltip"]').tooltip();
})

// JS for LEDs
$(function(){
	$('#powerOn').click(function(){
		//Power on for M&S Bay
		ledSwitchOn("specOnePower");
		ledSwitchOn("specTwoPower");
		ledSwitchOn("ethOnePower");
		ledSwitchOn("ethTwoPower");
		ledSwitchOn("ethThreePower");
		ledSwitchOn("msServerPower");
		ledSwitchOn("fiberServerPower");
		ledSwitchOn("ethernetServerPower");
		ledSwitchOn("muxServerPower");	
		
		//Power on for UUT Bay
		ledSwitchOn("digiPower");
		ledSwitchOn("uutPower");
		ledSwitchOn("fiberPower");
		ledSwitchOn("niPowerSupplyPower");
		
		//Power on for I\O Bay
		ledSwitchOn("niOnePower");
		ledSwitchOn("niTwoPower");
		ledSwitchOn("windowsOnePower");
		ledSwitchOn("windowsTwoPower");
		ledSwitchOn("linuxOnePower");
		ledSwitchOn("linuxTwoPower");
	})
	
	$('#connect').click(function(){
		//Connection for M&S Bay
		ledSwitchOn("specOneConnect");
		ledSwitchOn("specTwoConnect");
		ledSwitchOn("ethOneConnect");
		ledSwitchOn("ethTwoConnect");
		ledSwitchOn("ethThreeConnect");
		ledSwitchOn("msServerConnect");
		ledSwitchOn("fiberServerConnect");
		ledSwitchOn("ethernetServerConnect");
		ledSwitchOn("muxServerConnect");
		
		//Connection for UUT Bay
		ledSwitchOn("digiConnect");
		ledSwitchOn("fiberConnect");

		//Connection for I\O Bay
		ledSwitchOn("niConnect");
		ledSwitchOn("windowsOneConnect");
		ledSwitchOn("windowsTwoConnect");
		ledSwitchOn("linuxOneConnect");
		ledSwitchOn("linuxTwoConnect");

		//Connection for Fiber Modal
		ledSwitchOn("bladeA");
		ledSwitchOn("6A");
		ledSwitchOn("7A");
		ledSwitchOn("8A");
		ledSwitchOn("9A");
		ledSwitchOn("10A");
	})

	$('#powerOff').click(function(){
		//Power off for M&S Bay
		ledSwitchOff("specOnePower");
		ledSwitchOff("specTwoPower");
		ledSwitchOff("ethOnePower");
		ledSwitchOff("ethTwoPower");
		ledSwitchOff("ethThreePower");
		ledSwitchOff("msServerPower");
		ledSwitchOff("fiberServerPower");
		ledSwitchOff("ethernetServerPower");
		ledSwitchOff("muxServerPower");	
		
		//Power off for UUT Bay
		ledSwitchOff("digiPower");
		ledSwitchOff("uutPower");
		ledSwitchOff("fiberPower");
		ledSwitchOff("niPowerSupplyPower");

		//Power off for I\O Bay
		ledSwitchOff("niOnePower");
		ledSwitchOff("niTwoPower");
		ledSwitchOff("windowsOnePower");
		ledSwitchOff("windowsTwoPower");
		ledSwitchOff("linuxOnePower");
		ledSwitchOff("linuxTwoPower");
	})

	$('#disconnect').click(function(){
		//Disconnect for M&S Bay
		ledSwitchOff("specOneConnect");
		ledSwitchOff("specTwoConnect");
		ledSwitchOff("ethOneConnect");
		ledSwitchOff("ethTwoConnect");
		ledSwitchOff("ethThreeConnect");
		ledSwitchOff("msServerConnect");
		ledSwitchOff("fiberServerConnect");
		ledSwitchOff("ethernetServerConnect");
		ledSwitchOff("muxServerConnect");
		
		//Disconnect for UUT
		ledSwitchOff("digiConnect");
		ledSwitchOff("fiberConnect");

		//Disconnect for I\O
		ledSwitchOff("niConnect");
		ledSwitchOff("windowsOneConnect");
		ledSwitchOff("windowsTwoConnect");
		ledSwitchOff("linuxOneConnect");
		ledSwitchOff("linuxTwoConnect");

		//Disconnect for Fiber Modal
		ledSwitchOff("bladeA");
		ledSwitchOff("6A");
		ledSwitchOff("7A");
		ledSwitchOff("8A");
		ledSwitchOff("9A");
		ledSwitchOff("10A");
	})
})

/*Function to switch LEDs on for both power on and connection*/
function ledSwitchOn(id){
	var element = $('#'+id)
	switch (element.attr('class')){
		case 'led-red':
			element.removeClass("led-red");
			element.addClass("led-green");
			break;
		case 'led-yellow':
			element.removeClass("led-yellow");
			element.addClass("led-blue");
			break;
		case 'led-yellow led-fiber-blades':
			element.removeClass("led-yellow led-fiber-blades");
			element.addClass("led-blue led-fiber-blades");
			break;
		case 'led-yellow led-fiber-ports':
			element.removeClass("led-yellow led-fiber-ports");
			element.addClass("led-blue led-fiber-ports");
			break;

	}
}

/*Function to switch LEDs off for both power off and disconnection*/
function ledSwitchOff(id){
	var element = $('#'+id)
	switch (element.attr('class')){
		case 'led-green':
			element.removeClass("led-green");
			element.addClass("led-red");
			break;
		case 'led-blue':
			element.removeClass("led-blue");
			element.addClass("led-yellow");
			break;
		case 'led-blue led-fiber-blades':
			element.removeClass("led-blue led-fiber-blades");
			element.addClass("led-yellow led-fiber-blades");
			break;
		case 'led-blue led-fiber-ports':
			element.removeClass("led-blue led-fiber-ports");
			element.addClass("led-yellow led-fiber-ports");
			break;
	}
}

/*Function to pair both NI chassis together when 
hovering the mouse over one or the other*/
$ (function (){
	var element1= $("#niOne");
	var element2= $("#niTwo");
	element1.on("mouseenter", function(){
		element1.addClass("NI-hover");
		element2.addClass("NI-hover");
	});
	element1.on("mouseleave", function(){
		element1.removeClass("NI-hover");
		element2.removeClass("NI-hover");
	})
	element2.on("mouseenter", function(){
		element1.addClass("NI-hover");
		element2.addClass("NI-hover");
	});
	element2.on("mouseleave", function(){
		element1.removeClass("NI-hover");
		element2.removeClass("NI-hover");
	})
})