from django.urls import path
from . import views

# Link urls to views
urlpatterns = [
    path('', views.index, name='home'),
]