from django import forms
from . import models

class NewTestProcedureForm (forms.ModelForm):

    class Meta:
        model = models.TestProcedure
        exclude = ['score_date']

    team = forms.CharField(
        max_length=20,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter team name'
            }
        )
    )

    ifc = forms.CharField(
        label='IFC',
        max_length=20,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter IFC'
            }
        )
    )

    hsc = forms.CharField(
        label='HSC',
        max_length=20,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter HSC'
            }
        )
    )

    author = forms.CharField(
        max_length=100,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter author name'
            }
        )
    )

    name = forms.CharField(
        label='Test Procedure Name',
        max_length=100,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter test procedure name'
            }
        )
    )

    description = forms.CharField(
        widget=forms.Textarea(
            attrs={
                'class': 'form-control',
                'rows': '3',
                'placeholder': 'Describe the test procedure'
            }
        )
    )

class NewTestCaseForm (forms.ModelForm):
    
    class Meta:
        model = models.TestCase
        exclude = ['test_procedure']

    name = forms.CharField(
        label='Test Case Name',
        max_length=100,
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Enter test case name'
            }
        )
    )

    description = forms.CharField(
        widget=forms.Textarea(
            attrs={
                'class': 'form-control',
                'rows': '3',
                'placeholder': 'Describe the test case'
            }
        )
    )

class NewLabNoteForm (forms.ModelForm):

    class Meta:
        model = models.LabNote
        fields = ['comment']

    comment = forms.CharField(
        required = False,
        widget=forms.Textarea(
            attrs={
                'style': 'display:none',
                'id': 'note_text'
            }
        )
    )
    
class NewTestStepForm (forms.ModelForm):

    class Meta:
        model = models.TestStep
        exclude = ['test_case']

    # Customized Fields
    step_number = forms.IntegerField(
        label='Step Number',
        widget=forms.TextInput(
            attrs={
                'class': 'input-group-text',
                'style': 'text-align: left; width: 100%',
                'readonly': '',
            }
        )
    )

    classification = forms.ChoiceField(
        choices=models.CLASSIFICATION_CHOICES,
        widget=forms.Select(
            attrs={
                'class': 'form-control',
            }
        )
    )

    operator_action = forms.CharField(
        widget=forms.Textarea(
            attrs={
                'style': 'display: none',
                'id': 'operatorActionField',
            }
        )
    )

    expected_result = forms.CharField(
        widget=forms.Textarea(
            attrs={
                'style': 'display: none',
                'id': 'expectedResultField',
            }
        )
    )
    
    requirements = forms.ModelMultipleChoiceField(
        required=False,
        queryset=models.Requirement.objects.all(),
        widget=forms.CheckboxSelectMultiple()
    )
        
