from django.contrib import admin
from webapps.start.models import *

# Register your models here.
admin.site.register(TestProcedure)
admin.site.register(TestCase)
admin.site.register(TestStep)
admin.site.register(TestPoint)
admin.site.register(Requirement)
admin.site.register(LabNote)