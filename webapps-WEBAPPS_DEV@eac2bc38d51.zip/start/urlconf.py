from django.urls import path, re_path
from . import views

urlpatterns = [
    path('testProcedure/', views.file_newTestProcedure, name="new-test-procedure"),
    path('testProcedure/<t_proc>/', views.file_newTestCase, name="new-test-case"),
    path('testProcedure/<t_proc>/<t_case>/', views.file_newTestStep, name="new-test-step"),
    path('testProcedure/<t_proc>/<t_case>/<t_step>', views.testProcedureEditor, name="test-step-editor"),
    path('', views.index, name='start'),
]