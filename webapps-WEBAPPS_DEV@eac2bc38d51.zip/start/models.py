from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

### DATA ENUMERATIONS ###
# Enum for Classification
CLASSIFICATION_CHOICES = [('U', 'Unclassified'),
                          ('C', 'Confidential'),
                          ('S', 'Secret'),
                          ('TS', 'Top Secret')]

# Enum for Test States
TEST_STATE_CHOICES = [('E', 'Excluded'),
                      ('P', 'Passed'),
                      ('N', 'Not Tested'),
                      ('B', 'Blocked'),
                      ('F', 'Failed')]
                      
### Test Procedure Model ###
""" A test procedure is an object that contains
    test cases, which in turn contain test 
    steps. A test procedure must contain at least 
    one test case or it is set to 'inactive'
    and archived."""
class TestProcedure (models.Model):
    ifc = models.CharField("integrated functional capability", max_length=20)   # Will be ForeignKey from IFC table
    hsc = models.CharField("hardware software compatibility", max_length=20)    # Will be ForeignKey from HSC table
    team = models.CharField(max_length=20)      # Will be ForeignKey from Teams table
    author = models.CharField(max_length=100)   # Will be ForeignKey from Users table
    name = models.CharField(max_length=100)
    description = models.TextField()
    score_date = models.DateField(blank=True, null=True)

    def __str__(self):
        return str(self.id) + ": " + str(self.name)

### Test Case Model ###
""" A test case is a container for test steps.
    This allows users to group similar steps,
    for instance: if multiple steps apply to 
    ethernet testing, a user might group them in
    a test case named 'ethernet.' Test cases 
    must include at least one test step."""
class TestCase (models.Model):
    test_procedure = models.ForeignKey('TestProcedure', null=True, on_delete=models.SET_NULL)

    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return str(self.id) + ": " + str(self.name)

### Test Step Model ###
""" A test step is the fundamental component of
    a test procedure. Test steps contain the 
    instructions for the tester and the expected
    results. Test steps are ordered and may have
    requirements linked to them."""
class TestStep (models.Model):
    test_case = models.ForeignKey('TestCase', null=True, on_delete=models.SET_NULL)
    requirements = models.ManyToManyField('Requirement', blank=True)

    step_number = models.PositiveIntegerField()
    classification = models.CharField(max_length=4, default='U', choices=CLASSIFICATION_CHOICES)
    operator_action = models.TextField()
    expected_result = models.TextField()

    def __str__(self):
        return str(self.id) + ": " + str(self.test_case.test_procedure.name) + " step " + str(self.step_number)

### Test Point Model ###
""" A test point is a test step with additional
    fields. Any test step may be converted to a 
    test point, allowing it to be scored with a
    test state and a comment. Modifying a test 
    point will also modify the associated test 
    step."""
class TestPoint (TestStep):
    test_state = models.CharField(max_length=4, default='N', choices=TEST_STATE_CHOICES)
    comment = models.TextField(blank=True, null=True)

### Requirement Model ###
""" A requirement is a linking between a shall
    and a test step. Test steps may have many 
    requirements, and multiple test steps may 
    link to the same requirement. """
class Requirement (models.Model):
    shall_id = models.CharField(max_length=20)
    sstr_number = models.CharField(blank=True, null=True, max_length=20)
    epic_id = models.CharField(blank=True, null=True, max_length=20)
    test_state = models.CharField(max_length=4, default='N', choices=TEST_STATE_CHOICES)

    def __str__(self):
        return str(self.id) + ": " + str(self.shall_id)

### Lab Note Model ###
""" A Lab Note contain information important to
    testers conducting the test. They link to 
    other models through a Generic Foreign Key,
    which allows us to link lab notes to any
    model regardless of that model's class. """
class LabNote (models.Model):
    content_type = models.ForeignKey(ContentType, null=True, on_delete=models.SET_NULL)
    object_id = models.PositiveIntegerField()
    parent = GenericForeignKey()    # Allows linking to any model class (rather than just 1)

    comment = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.id) + ": (" + str(self.parent) + ")"
