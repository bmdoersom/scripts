from django.shortcuts import render, reverse, get_object_or_404
from django.http import HttpResponseRedirect
from django.db.models import QuerySet
from webapps.start.forms import *
from webapps.start.models import *

# The default page for START
def index(request):
    return render(request, 'start.html')

# Test Procedure Editor
def testProcedureEditor(request, t_proc, t_case, t_step):
    return render(request, 'testProcedureEditor.html')

# FILE MENU

# New Procedure
def file_newTestProcedure(request):
    # If this is a POST request we need to process form data
    if request.method == 'POST':
        testProcedureForm = NewTestProcedureForm(request.POST, prefix='procedure')
        labNotesForm = NewLabNoteForm(request.POST, prefix='note')
        # Check whether the testProcedureform is valid. Lab note form will always be valid
        if testProcedureForm.is_valid() and labNotesForm.is_valid():
            # Save the test procedure to the database
            t_proc = testProcedureForm.save()
            # Check if there is a lab note
            if labNotesForm.cleaned_data['comment'] != '':
                lab_note = labNotesForm.save(commit=False)
                # Assign the lab note to the test procedure
                lab_note.parent = t_proc
                # Save the lab note
                lab_note.save()
            # Redirect using the reverse function: https://docs.djangoproject.com/en/2.2/ref/urlresolvers/#reverse
            return HttpResponseRedirect(reverse('new-test-case', kwargs={'t_proc': t_proc.id}))
    # Load a new form if the request is not "POST"
    else:
        testProcedureForm = NewTestProcedureForm(prefix='procedure')
        labNotesForm = NewLabNoteForm(prefix='note')

    return render(request, 'file/newTestProcedure.html', {'test_procedure_form': testProcedureForm, 'lab_notes_form': labNotesForm})

# New test case
def file_newTestCase(request, t_proc):
    # If this is a POST request we need to process form data
    if request.method == 'POST':
        testCaseForm = NewTestCaseForm(request.POST, prefix='case')
        labNotesForm = NewLabNoteForm(request.POST, prefix='note')
        # Check if test case form is valid. Lab note form will always be valid
        if testCaseForm.is_valid() and labNotesForm.is_valid():
            # Link the test case to its parent test procedure
            t_case = testCaseForm.save(commit=False)
            t_case.test_procedure = get_object_or_404(TestProcedure, id=t_proc) # assign t_proc as t_case's FK
            # Save the test case
            t_case = testCaseForm.save()
            # Check if the lab note has been edited
            if labNotesForm.cleaned_data['comment'] != '':
                # Assign the lab note to the test case
                lab_note = labNotesForm.save(commit=False)
                lab_note.parent = t_case
                # Save the lab note
                lab_note.save()
            # Redirect to the New Test Step page
            return HttpResponseRedirect(reverse('new-test-step', kwargs={'t_proc': t_proc, 't_case': t_case.id}))
    # Load a new form if the request is not "POST"
    else:
        testCaseForm = NewTestCaseForm(prefix='case')
        labNotesForm = NewLabNoteForm(prefix='note')

    return render(request, 'file/newTestCase.html', {'test_case_form': testCaseForm, 'lab_notes_form':labNotesForm})

# New test step
def file_newTestStep(request, t_proc, t_case):

    # If this is a POST request we need to process form data
    if request.method == 'POST':
        testStepForm = NewTestStepForm(request.POST, prefix='step')
        labNotesForm = NewLabNoteForm(request.POST, prefix='note')
        if testStepForm.is_valid() and labNotesForm.is_valid():
            t_step = testStepForm.save(commit=False)                            # Get the test step
            t_step.test_case = get_object_or_404(TestCase, id=t_case)   # Link the step to its parent test case
            t_step.save()                                               # Save the test step to the database
            t_step.requirements.set(testStepForm.cleaned_data['requirements'])  # Link requirements to the t_step

            if labNotesForm.cleaned_data['comment'] != '':
                lab_note = labNotesForm.save(commit=False)
                lab_note.parent = t_step
                lab_note.save()

            # Redirect to add another test step
            return HttpResponseRedirect(reverse("new-test-step", kwargs={'t_proc': t_proc, 't_case': t_case}))

    # If this is a GET (or any other) request we need an unbound form
    else:
        # Assign the correct step number to the new test step
        try:
            # Get the last step in the database, and add 1 to its step number
            tc = TestCase.objects.filter(test_procedure=t_proc).order_by('-id')
            steps = []
            for case in tc:
                s = TestStep.objects.filter(test_case=case).order_by('-step_number')
                if len(s) > 0:
                    steps.append(s)
            stepnum = steps[0][0].step_number + 1
        except IndexError:
            # If there are no steps in the database for this procedure, this is the first step
            stepnum = 1
        # Create a blank form with the step number initialized
        testStepForm = NewTestStepForm(initial={'step_number': stepnum}, prefix='step')
        labNotesForm = NewLabNoteForm(prefix='note')
    return render(request, 'testProcedureEditor.html', {'test_step_form': testStepForm, 'lab_notes_form': labNotesForm})
