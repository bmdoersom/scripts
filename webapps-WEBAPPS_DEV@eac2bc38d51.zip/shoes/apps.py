from django.apps import AppConfig


class ShoesConfig(AppConfig):
    name = 'shoes'
