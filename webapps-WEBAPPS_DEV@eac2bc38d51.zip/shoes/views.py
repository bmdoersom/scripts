from django.shortcuts import render

# Create your views here.
def sits(request):
    return render(request, 'sits.html')

def mits(request):
    return render(request, 'mits.html')